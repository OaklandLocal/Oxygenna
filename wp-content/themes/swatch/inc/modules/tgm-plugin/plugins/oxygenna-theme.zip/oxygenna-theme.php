<?php
/*
Plugin Name: Oxygenna Theme Framework
Version: 1.4.4
Plugin URI: https://github.com/oxygenna/oxygenna-theme
Description: Main Framework for all oxygenna themes
Author: Oxygenna.com
Author URI: http://www.oxygenna.com
License: http://wiki.envato.com/support/legal-terms/licensing-terms/
*/

define( 'OXY_FRAMEWORK_DIR', plugin_dir_path( __FILE__ ) . 'inc/' );
define( 'OXY_FRAMEWORK_URI', plugin_dir_url( __FILE__ ) . 'inc/' );

require_once OXY_FRAMEWORK_DIR . 'theme.php';