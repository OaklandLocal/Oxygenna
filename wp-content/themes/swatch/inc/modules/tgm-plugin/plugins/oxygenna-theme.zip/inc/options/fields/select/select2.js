jQuery(document).ready(function($) {
    // create jquery ui radio buttons
    $('.select2').select2();
});