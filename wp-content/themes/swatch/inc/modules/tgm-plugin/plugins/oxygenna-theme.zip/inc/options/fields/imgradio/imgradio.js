jQuery(document).ready(function($) {
    // create jquery ui radio buttons
    $('.ui-imgradio').buttonset();
});