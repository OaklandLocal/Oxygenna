<?php
/*
Plugin Name: Oxygenna Typography Plugin
Version: 1.1.2
Plugin URI: https://github.com/oxygenna/oxygenna-type
Description: Adds extra typography options to oxygenna themes
Author: Oxygenna.com
Author URI: http://www.oxygenna.com
License: http://wiki.envato.com/support/legal-terms/licensing-terms/
*/

define( 'OXY_TYPE_DIR', plugin_dir_path( __FILE__ ) . 'inc/' );
define( 'OXY_TYPE_URI', plugin_dir_url( __FILE__ ) . 'inc/' );

require_once OXY_TYPE_DIR . 'OxyTypography.php';

global $oxy_typography;
$oxy_typography = new OxyTypography();